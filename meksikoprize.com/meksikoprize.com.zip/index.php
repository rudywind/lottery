<!DOCTYPE html>
<html lang="es-MX">

<head>
    <!-- wp_head -->
    <title>Mexico Prize &#8211; Official lottery website</title>
    <meta name='robots' content='max-image-preview:large' />
    <script type="text/javascript">
        /* <![CDATA[ */
        window._wpemojiSettings = { "baseUrl": "https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/72x72\/", "ext": ".png", "svgUrl": "https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/svg\/", "svgExt": ".svg", "source": { "concatemoji": "https:\/\/lotteriamexico.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.4.2" } };
        /*! This file is auto-generated */
        !function (i, n) { var o, s, e; function c(e) { try { var t = { supportTests: e, timestamp: (new Date).valueOf() }; sessionStorage.setItem(o, JSON.stringify(t)) } catch (e) { } } function p(e, t, n) { e.clearRect(0, 0, e.canvas.width, e.canvas.height), e.fillText(t, 0, 0); var t = new Uint32Array(e.getImageData(0, 0, e.canvas.width, e.canvas.height).data), r = (e.clearRect(0, 0, e.canvas.width, e.canvas.height), e.fillText(n, 0, 0), new Uint32Array(e.getImageData(0, 0, e.canvas.width, e.canvas.height).data)); return t.every(function (e, t) { return e === r[t] }) } function u(e, t, n) { switch (t) { case "flag": return n(e, "\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f", "\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f") ? !1 : !n(e, "\ud83c\uddfa\ud83c\uddf3", "\ud83c\uddfa\u200b\ud83c\uddf3") && !n(e, "\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f", "\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f"); case "emoji": return !n(e, "\ud83e\udef1\ud83c\udffb\u200d\ud83e\udef2\ud83c\udfff", "\ud83e\udef1\ud83c\udffb\u200b\ud83e\udef2\ud83c\udfff") }return !1 } function f(e, t, n) { var r = "undefined" != typeof WorkerGlobalScope && self instanceof WorkerGlobalScope ? new OffscreenCanvas(300, 150) : i.createElement("canvas"), a = r.getContext("2d", { willReadFrequently: !0 }), o = (a.textBaseline = "top", a.font = "600 32px Arial", {}); return e.forEach(function (e) { o[e] = t(a, e, n) }), o } function t(e) { var t = i.createElement("script"); t.src = e, t.defer = !0, i.head.appendChild(t) } "undefined" != typeof Promise && (o = "wpEmojiSettingsSupports", s = ["flag", "emoji"], n.supports = { everything: !0, everythingExceptFlag: !0 }, e = new Promise(function (e) { i.addEventListener("DOMContentLoaded", e, { once: !0 }) }), new Promise(function (t) { var n = function () { try { var e = JSON.parse(sessionStorage.getItem(o)); if ("object" == typeof e && "number" == typeof e.timestamp && (new Date).valueOf() < e.timestamp + 604800 && "object" == typeof e.supportTests) return e.supportTests } catch (e) { } return null }(); if (!n) { if ("undefined" != typeof Worker && "undefined" != typeof OffscreenCanvas && "undefined" != typeof URL && URL.createObjectURL && "undefined" != typeof Blob) try { var e = "postMessage(" + f.toString() + "(" + [JSON.stringify(s), u.toString(), p.toString()].join(",") + "));", r = new Blob([e], { type: "text/javascript" }), a = new Worker(URL.createObjectURL(r), { name: "wpTestEmojiSupports" }); return void (a.onmessage = function (e) { c(n = e.data), a.terminate(), t(n) }) } catch (e) { } c(n = f(s, u, p)) } t(n) }).then(function (e) { for (var t in e) n.supports[t] = e[t], n.supports.everything = n.supports.everything && n.supports[t], "flag" !== t && (n.supports.everythingExceptFlag = n.supports.everythingExceptFlag && n.supports[t]); n.supports.everythingExceptFlag = n.supports.everythingExceptFlag && !n.supports.flag, n.DOMReady = !1, n.readyCallback = function () { n.DOMReady = !0 } }).then(function () { return e }).then(function () { var e; n.supports.everything || (n.readyCallback(), (e = n.source || {}).concatemoji ? t(e.concatemoji) : e.wpemoji && e.twemoji && (t(e.twemoji), t(e.wpemoji))) })) }((window, document), window._wpemojiSettings);
        /* ]]> */
    </script>
    <style id='wp-emoji-styles-inline-css' type='text/css'>
        img.wp-smiley,
        img.emoji {
            display: inline !important;
            border: none !important;
            box-shadow: none !important;
            height: 1em !important;
            width: 1em !important;
            margin: 0 0.07em !important;
            vertical-align: -0.1em !important;
            background: none !important;
            padding: 0 !important;
        }
    </style>
    <link rel='stylesheet' id='wp-block-library-css'
        href='assets/style.min.css?ver=6.4.2' type='text/css'
        media='all' />
    <style id='classic-theme-styles-inline-css' type='text/css'>
        /*! This file is auto-generated */
        .wp-block-button__link {
            color: #fff;
            background-color: #32373c;
            border-radius: 9999px;
            box-shadow: none;
            text-decoration: none;
            padding: calc(.667em + 2px) calc(1.333em + 2px);
            font-size: 1.125em
        }

        .wp-block-file__button {
            background: #32373c;
            color: #fff;
            text-decoration: none
        }
    </style>
    <style id='global-styles-inline-css' type='text/css'>
        body {
            --wp--preset--color--black: #000000;
            --wp--preset--color--cyan-bluish-gray: #abb8c3;
            --wp--preset--color--white: #ffffff;
            --wp--preset--color--pale-pink: #f78da7;
            --wp--preset--color--vivid-red: #cf2e2e;
            --wp--preset--color--luminous-vivid-orange: #ff6900;
            --wp--preset--color--luminous-vivid-amber: #fcb900;
            --wp--preset--color--light-green-cyan: #7bdcb5;
            --wp--preset--color--vivid-green-cyan: #00d084;
            --wp--preset--color--pale-cyan-blue: #8ed1fc;
            --wp--preset--color--vivid-cyan-blue: #0693e3;
            --wp--preset--color--vivid-purple: #9b51e0;
            --wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg, rgba(6, 147, 227, 1) 0%, rgb(155, 81, 224) 100%);
            --wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg, rgb(122, 220, 180) 0%, rgb(0, 208, 130) 100%);
            --wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg, rgba(252, 185, 0, 1) 0%, rgba(255, 105, 0, 1) 100%);
            --wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg, rgba(255, 105, 0, 1) 0%, rgb(207, 46, 46) 100%);
            --wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg, rgb(238, 238, 238) 0%, rgb(169, 184, 195) 100%);
            --wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg, rgb(74, 234, 220) 0%, rgb(151, 120, 209) 20%, rgb(207, 42, 186) 40%, rgb(238, 44, 130) 60%, rgb(251, 105, 98) 80%, rgb(254, 248, 76) 100%);
            --wp--preset--gradient--blush-light-purple: linear-gradient(135deg, rgb(255, 206, 236) 0%, rgb(152, 150, 240) 100%);
            --wp--preset--gradient--blush-bordeaux: linear-gradient(135deg, rgb(254, 205, 165) 0%, rgb(254, 45, 45) 50%, rgb(107, 0, 62) 100%);
            --wp--preset--gradient--luminous-dusk: linear-gradient(135deg, rgb(255, 203, 112) 0%, rgb(199, 81, 192) 50%, rgb(65, 88, 208) 100%);
            --wp--preset--gradient--pale-ocean: linear-gradient(135deg, rgb(255, 245, 203) 0%, rgb(182, 227, 212) 50%, rgb(51, 167, 181) 100%);
            --wp--preset--gradient--electric-grass: linear-gradient(135deg, rgb(202, 248, 128) 0%, rgb(113, 206, 126) 100%);
            --wp--preset--gradient--midnight: linear-gradient(135deg, rgb(2, 3, 129) 0%, rgb(40, 116, 252) 100%);
            --wp--preset--font-size--small: 13px;
            --wp--preset--font-size--medium: 20px;
            --wp--preset--font-size--large: 36px;
            --wp--preset--font-size--x-large: 42px;
            --wp--preset--spacing--20: 0.44rem;
            --wp--preset--spacing--30: 0.67rem;
            --wp--preset--spacing--40: 1rem;
            --wp--preset--spacing--50: 1.5rem;
            --wp--preset--spacing--60: 2.25rem;
            --wp--preset--spacing--70: 3.38rem;
            --wp--preset--spacing--80: 5.06rem;
            --wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);
            --wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);
            --wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);
            --wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);
            --wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);
        }

        :where(.is-layout-flex) {
            gap: 0.5em;
        }

        :where(.is-layout-grid) {
            gap: 0.5em;
        }

        body .is-layout-flow>.alignleft {
            float: left;
            margin-inline-start: 0;
            margin-inline-end: 2em;
        }

        body .is-layout-flow>.alignright {
            float: right;
            margin-inline-start: 2em;
            margin-inline-end: 0;
        }

        body .is-layout-flow>.aligncenter {
            margin-left: auto !important;
            margin-right: auto !important;
        }

        body .is-layout-constrained>.alignleft {
            float: left;
            margin-inline-start: 0;
            margin-inline-end: 2em;
        }

        body .is-layout-constrained>.alignright {
            float: right;
            margin-inline-start: 2em;
            margin-inline-end: 0;
        }

        body .is-layout-constrained>.aligncenter {
            margin-left: auto !important;
            margin-right: auto !important;
        }

        body .is-layout-constrained> :where(:not(.alignleft):not(.alignright):not(.alignfull)) {
            max-width: var(--wp--style--global--content-size);
            margin-left: auto !important;
            margin-right: auto !important;
        }

        body .is-layout-constrained>.alignwide {
            max-width: var(--wp--style--global--wide-size);
        }

        body .is-layout-flex {
            display: flex;
        }

        body .is-layout-flex {
            flex-wrap: wrap;
            align-items: center;
        }

        body .is-layout-flex>* {
            margin: 0;
        }

        body .is-layout-grid {
            display: grid;
        }

        body .is-layout-grid>* {
            margin: 0;
        }

        :where(.wp-block-columns.is-layout-flex) {
            gap: 2em;
        }

        :where(.wp-block-columns.is-layout-grid) {
            gap: 2em;
        }

        :where(.wp-block-post-template.is-layout-flex) {
            gap: 1.25em;
        }

        :where(.wp-block-post-template.is-layout-grid) {
            gap: 1.25em;
        }

        .has-black-color {
            color: var(--wp--preset--color--black) !important;
        }

        .has-cyan-bluish-gray-color {
            color: var(--wp--preset--color--cyan-bluish-gray) !important;
        }

        .has-white-color {
            color: var(--wp--preset--color--white) !important;
        }

        .has-pale-pink-color {
            color: var(--wp--preset--color--pale-pink) !important;
        }

        .has-vivid-red-color {
            color: var(--wp--preset--color--vivid-red) !important;
        }

        .has-luminous-vivid-orange-color {
            color: var(--wp--preset--color--luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-amber-color {
            color: var(--wp--preset--color--luminous-vivid-amber) !important;
        }

        .has-light-green-cyan-color {
            color: var(--wp--preset--color--light-green-cyan) !important;
        }

        .has-vivid-green-cyan-color {
            color: var(--wp--preset--color--vivid-green-cyan) !important;
        }

        .has-pale-cyan-blue-color {
            color: var(--wp--preset--color--pale-cyan-blue) !important;
        }

        .has-vivid-cyan-blue-color {
            color: var(--wp--preset--color--vivid-cyan-blue) !important;
        }

        .has-vivid-purple-color {
            color: var(--wp--preset--color--vivid-purple) !important;
        }

        .has-black-background-color {
            background-color: var(--wp--preset--color--black) !important;
        }

        .has-cyan-bluish-gray-background-color {
            background-color: var(--wp--preset--color--cyan-bluish-gray) !important;
        }

        .has-white-background-color {
            background-color: var(--wp--preset--color--white) !important;
        }

        .has-pale-pink-background-color {
            background-color: var(--wp--preset--color--pale-pink) !important;
        }

        .has-vivid-red-background-color {
            background-color: var(--wp--preset--color--vivid-red) !important;
        }

        .has-luminous-vivid-orange-background-color {
            background-color: var(--wp--preset--color--luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-amber-background-color {
            background-color: var(--wp--preset--color--luminous-vivid-amber) !important;
        }

        .has-light-green-cyan-background-color {
            background-color: var(--wp--preset--color--light-green-cyan) !important;
        }

        .has-vivid-green-cyan-background-color {
            background-color: var(--wp--preset--color--vivid-green-cyan) !important;
        }

        .has-pale-cyan-blue-background-color {
            background-color: var(--wp--preset--color--pale-cyan-blue) !important;
        }

        .has-vivid-cyan-blue-background-color {
            background-color: var(--wp--preset--color--vivid-cyan-blue) !important;
        }

        .has-vivid-purple-background-color {
            background-color: var(--wp--preset--color--vivid-purple) !important;
        }

        .has-black-border-color {
            border-color: var(--wp--preset--color--black) !important;
        }

        .has-cyan-bluish-gray-border-color {
            border-color: var(--wp--preset--color--cyan-bluish-gray) !important;
        }

        .has-white-border-color {
            border-color: var(--wp--preset--color--white) !important;
        }

        .has-pale-pink-border-color {
            border-color: var(--wp--preset--color--pale-pink) !important;
        }

        .has-vivid-red-border-color {
            border-color: var(--wp--preset--color--vivid-red) !important;
        }

        .has-luminous-vivid-orange-border-color {
            border-color: var(--wp--preset--color--luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-amber-border-color {
            border-color: var(--wp--preset--color--luminous-vivid-amber) !important;
        }

        .has-light-green-cyan-border-color {
            border-color: var(--wp--preset--color--light-green-cyan) !important;
        }

        .has-vivid-green-cyan-border-color {
            border-color: var(--wp--preset--color--vivid-green-cyan) !important;
        }

        .has-pale-cyan-blue-border-color {
            border-color: var(--wp--preset--color--pale-cyan-blue) !important;
        }

        .has-vivid-cyan-blue-border-color {
            border-color: var(--wp--preset--color--vivid-cyan-blue) !important;
        }

        .has-vivid-purple-border-color {
            border-color: var(--wp--preset--color--vivid-purple) !important;
        }

        .has-vivid-cyan-blue-to-vivid-purple-gradient-background {
            background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;
        }

        .has-light-green-cyan-to-vivid-green-cyan-gradient-background {
            background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;
        }

        .has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background {
            background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-orange-to-vivid-red-gradient-background {
            background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;
        }

        .has-very-light-gray-to-cyan-bluish-gray-gradient-background {
            background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;
        }

        .has-cool-to-warm-spectrum-gradient-background {
            background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;
        }

        .has-blush-light-purple-gradient-background {
            background: var(--wp--preset--gradient--blush-light-purple) !important;
        }

        .has-blush-bordeaux-gradient-background {
            background: var(--wp--preset--gradient--blush-bordeaux) !important;
        }

        .has-luminous-dusk-gradient-background {
            background: var(--wp--preset--gradient--luminous-dusk) !important;
        }

        .has-pale-ocean-gradient-background {
            background: var(--wp--preset--gradient--pale-ocean) !important;
        }

        .has-electric-grass-gradient-background {
            background: var(--wp--preset--gradient--electric-grass) !important;
        }

        .has-midnight-gradient-background {
            background: var(--wp--preset--gradient--midnight) !important;
        }

        .has-small-font-size {
            font-size: var(--wp--preset--font-size--small) !important;
        }

        .has-medium-font-size {
            font-size: var(--wp--preset--font-size--medium) !important;
        }

        .has-large-font-size {
            font-size: var(--wp--preset--font-size--large) !important;
        }

        .has-x-large-font-size {
            font-size: var(--wp--preset--font-size--x-large) !important;
        }

        .wp-block-navigation a:where(:not(.wp-element-button)) {
            color: inherit;
        }

        :where(.wp-block-post-template.is-layout-flex) {
            gap: 1.25em;
        }

        :where(.wp-block-post-template.is-layout-grid) {
            gap: 1.25em;
        }

        :where(.wp-block-columns.is-layout-flex) {
            gap: 2em;
        }

        :where(.wp-block-columns.is-layout-grid) {
            gap: 2em;
        }

        .wp-block-pullquote {
            font-size: 1.5em;
            line-height: 1.6;
        }
    </style>
    <link rel="https://api.w.org/" href="https://meksikoprize.com/wp-json/" />
    <link rel="alternate" type="application/json" href="https://meksikoprize.com/wp-json/wp/v2/pages/160" />
    <link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://meksikoprize.com/xmlrpc.php?rsd" />
    <meta name="generator" content="WordPress 6.4.2" />
    <link rel="canonical" href="https://meksikoprize.com/" />
    <link rel='shortlink' href='https://meksikoprize.com/' />
    <link rel="alternate" type="application/json+oembed"
        href="https://meksikoprize.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Flotteriamexico.com%2F" />
    <link rel="alternate" type="text/xml+oembed"
        href="https://meksikoprize.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Flotteriamexico.com%2F&#038;format=xml" />
    <style type="text/css" id="custom-background-css">
        body.custom-background {
            background-image: url("assets/bg.jpg");
            background-position: center center;
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
    </style>
    <link rel="icon" href="assets/icon.png"
        sizes="32x32" />
    <link rel="icon" href="assets/icon.png"
        sizes="192x192" />
    <link rel="apple-touch-icon" href="assets/icon.png" />
    <meta name="msapplication-TileImage"
        content="assets/icon.png" />
    <!-- meta -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <meta name="description" content="Official lottery website">
    <!-- link -->
    <link rel="shortcut icon" href="assets/icon.png">
    <!-- style -->
    <link rel="stylesheet" href="assets/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="assets/flipclock.css">
    <link rel="stylesheet" href="assets/lottery.css">
    <!-- script -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.2.1/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap4.min.js"></script>
    <script src="assets/flipclock.js"></script>
    <script src="assets/lottery.js"></script>
    <script src="assets/ui.js"></script>
    <script src="setting.js?v=<?=time();?>"></script>
</head>


<script>
function DatesFormatNew(format) {
  const [day, month, year] = ResultDate.split('-');
  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  switch (format.toLowerCase()) {
    case 'month':
      return monthNames[parseInt(month) - 1];
    case 'day':
      return day;
    case 'year':
      return year;
    default:
      return null; 
  }
}

</script>

<body
    class="home page-template page-template-page-home page-template-page-home-php page page-id-160 custom-background wp-custom-logo">

    <!-- component header below -->
    <div class="bg-glass"></div>

    <header>
        <div class="container px-3 py-0">
            <div class="header-wrapper px-3 py-4">
                <div class="logo-wrapper px-3 py-3">
                    <a href="https://meksikoprize.com/"><img class="web-logo"
                            src="assets/logo.png"></a>
                </div>
            </div>
            <div class="menu-wrapper bg-color-3 px-3 py-3">
                <div class="row no-gutters justify-content-between align-items-center">
                    <div class="col-12 col-lg-auto">
                        <div class="time-wrapper mb-2 mb-lg-0">
                            <div class="row no-gutters justify-content-center align-items-center">
                                <div class="col-auto">
                                    <h6 class="text-title text-white text-center text-lg-right font-weight-bold mb-0">
                                        <span>Next result&nbsp;:&nbsp;</span>
                                    </h6>
                                </div>
                                <div class="col-auto">
                                    <div class="row no-gutters justify-content-center justify-content-lg-end">
                                        <div class="col-auto">
                                            <div data-time="68116" id="countdown-lottery" class="clock m-0 text-center">
                                            </div>
                                            <script
                                                type="text/javascript">    $(document).ready(function () { $("#countdown-lottery").FlipClock($("#countdown-lottery").attr("data-time"), { countdown: true, callbacks: { stop: function () { window.location.href = "https://lotteriamexico.com/en/live-draw/"; } } }); });</script>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-auto">
                        <p class="text-white text-center mb-0">
                            <span>Live draw every day on: </span>
                            <span class="badge badge-danger px-1 py-2">22:45 PM</span>
                            <span>&nbsp;to&nbsp;</span>
                            <span class="badge badge-danger px-1 py-2">23:00 PM</span>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- content page home below -->
    <section>
        <div class="container px-3 py-0">
            <div class="content-wrapper px-0 py-4 py-lg-5">
                <div class="row align-items-center">
                    <div class="col-12 col-lg-auto">
                        <!-- component card below -->
                        <div class="card card-result shadow bg-gradient-2 border-0 mb-3 mb-lg-0">
                            <div class="card-header bg-transparent border-0 px-3 py-0">
                                <div class="row no-gutters">
                                    <div class="col-auto">
                                        <div class="card-date bg-color-6 text-white shadow">
                                            <div class="date-month"><script>document.write(DatesFormatNew('month'));</script></div>
                                            <div class="date-day"><script>document.write(DatesFormatNew('day'));</script></div>
                                            <div class="date-year"><script>document.write(DatesFormatNew('year'));</script></div>
                                        </div>
                                        
                                    </div>
                                    <div class="col">
                                        <div class="card-title pl-3 py-3">
                                            <h4 class="text-black text-center text-uppercase font-weight-bold mb-2">
                                                <span>LOTTERY WINNER</span>
                                            </h4>
                                            <div class="pool-wrapper text-center text-white">
                                                <div id="lastdraw-lottery-main-1" class="text-center prize-wrapper">
                                                    <div class="prize-block d-inline-block winner ball-2">
                                                        <div class="prize-digit"> <span id="lastdraw-lottery-main-1-1"
                                                                data-parent="lastdraw-lottery-main-1"><script>document.write(WinnerStr[0]);</script></span> </div>
                                                    </div>
                                                    <div class="prize-block d-inline-block winner ball-0">
                                                        <div class="prize-digit"> <span id="lastdraw-lottery-main-1-2"
                                                                data-parent="lastdraw-lottery-main-1"><script>document.write(WinnerStr[1]);</script></span> </div>
                                                    </div>
                                                    <div class="prize-block d-inline-block winner ball-9">
                                                        <div class="prize-digit"> <span id="lastdraw-lottery-main-1-3"
                                                                data-parent="lastdraw-lottery-main-1"><script>document.write(WinnerStr[2]);</script></span> </div>
                                                    </div>
                                                    <div class="prize-block d-inline-block winner ball-5">
                                                        <div class="prize-digit"> <span id="lastdraw-lottery-main-1-4"
                                                                data-parent="lastdraw-lottery-main-1"><script>document.write(WinnerStr[3]);</script></span> </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body border-0 px-3 pt-0 pb-3">
                                <div class="row no-gutters justify-content-start align-items-center mb-2">
                                    <div class="col-12">
                                        <div
                                            class="card-title text-black text-left text-uppercase font-weight-bold mb-2">
                                            <div class="row no-gutters align-items-center">
                                                <div class="col">
                                                    <div class="separator"></div>
                                                </div>
                                                <div class="col-auto">
                                                    <span>PRIZE #2</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-9 col-lg-8">
                                        <div class="pool-wrapper text-center text-white">
                                            <div id="lastdraw-lottery-main-2" class="text-center prize-wrapper">
                                                <div class="prize-block d-inline-block ball-0">
                                                    <div class="prize-digit"> <span id="lastdraw-lottery-main-2-1"
                                                            data-parent="lastdraw-lottery-main-2"><script>document.write(SecWinStr[0]);</script></span> </div>
                                                </div>
                                                <div class="prize-block d-inline-block ball-4">
                                                    <div class="prize-digit"> <span id="lastdraw-lottery-main-2-2"
                                                            data-parent="lastdraw-lottery-main-2"><script>document.write(SecWinStr[1]);</script></span> </div>
                                                </div>
                                                <div class="prize-block d-inline-block ball-8">
                                                    <div class="prize-digit"> <span id="lastdraw-lottery-main-2-3"
                                                            data-parent="lastdraw-lottery-main-2"><script>document.write(SecWinStr[2]);</script></span> </div>
                                                </div>
                                                <div class="prize-block d-inline-block ball-8">
                                                    <div class="prize-digit"> <span id="lastdraw-lottery-main-2-4"
                                                            data-parent="lastdraw-lottery-main-2"><script>document.write(SecWinStr[3]);</script></span> </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row no-gutters justify-content-start align-items-center mb-2">
                                    <div class="col-12">
                                        <div
                                            class="card-title text-black text-left text-uppercase font-weight-bold mb-2">
                                            <div class="row no-gutters align-items-center">
                                                <div class="col">
                                                    <div class="separator"></div>
                                                </div>
                                                <div class="col-auto">
                                                    <span>PRIZE #3</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-9 col-lg-8">
                                        <div class="pool-wrapper text-center text-white">
                                            <div id="lastdraw-lottery-main-3" class="text-center prize-wrapper">
                                                <div class="prize-block d-inline-block ball-9">
                                                    <div class="prize-digit"> <span id="lastdraw-lottery-main-3-1"
                                                            data-parent="lastdraw-lottery-main-3"><script>document.write(ThrWinStr[0]);</script></span> </div>
                                                </div>
                                                <div class="prize-block d-inline-block ball-5">
                                                    <div class="prize-digit"> <span id="lastdraw-lottery-main-3-2"
                                                            data-parent="lastdraw-lottery-main-3"><script>document.write(ThrWinStr[1]);</script></span> </div>
                                                </div>
                                                <div class="prize-block d-inline-block ball-8">
                                                    <div class="prize-digit"> <span id="lastdraw-lottery-main-3-3"
                                                            data-parent="lastdraw-lottery-main-3"><script>document.write(ThrWinStr[2]);</script></span> </div>
                                                </div>
                                                <div class="prize-block d-inline-block ball-4">
                                                    <div class="prize-digit"> <span id="lastdraw-lottery-main-3-4"
                                                            data-parent="lastdraw-lottery-main-3"><script>document.write(ThrWinStr[3]);</script></span> </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row no-gutters justify-content-start align-items-center mb-2">
                                    <div class="col-12">
                                        <div
                                            class="card-title text-black text-left text-uppercase font-weight-bold mb-2">
                                            <div class="row no-gutters align-items-center">
                                                <div class="col">
                                                    <div class="separator"></div>
                                                </div>
                                                <div class="col-auto">
                                                    <span>STARTER</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-9 col-lg-8">
                                        <div class="pool-wrapper text-center text-white">
                                            <div id="lastdraw-lottery-main-3" class="text-center prize-wrapper">
                                                <div class="prize-block d-inline-block ball-9">
                                                    <div class="prize-digit"> <span id="lastdraw-lottery-main-3-1"
                                                            data-parent="lastdraw-lottery-main-3"><script>document.write(StartWinStr[0]);</script></span> </div>
                                                </div>
                                                <div class="prize-block d-inline-block ball-5">
                                                    <div class="prize-digit"> <span id="lastdraw-lottery-main-3-2"
                                                            data-parent="lastdraw-lottery-main-3"><script>document.write(StartWinStr[1]);</script></span> </div>
                                                </div>
                                                <div class="prize-block d-inline-block ball-8">
                                                    <div class="prize-digit"> <span id="lastdraw-lottery-main-3-3"
                                                            data-parent="lastdraw-lottery-main-3"><script>document.write(StartWinStr[2]);</script></span> </div>
                                                </div>
                                                <div class="prize-block d-inline-block ball-4">
                                                    <div class="prize-digit"> <span id="lastdraw-lottery-main-3-4"
                                                            data-parent="lastdraw-lottery-main-3"><script>document.write(StartWinStr[3]);</script></span> </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row no-gutters justify-content-start align-items-center">
                                    <div class="col-12">
                                        <div
                                            class="card-title text-black text-left text-uppercase font-weight-bold mb-2">
                                            <div class="row no-gutters align-items-center">
                                                <div class="col">
                                                    <div class="separator"></div>
                                                </div>
                                                <div class="col-auto">
                                                    <span>COMFORT</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-9 col-lg-8">
                                        <div class="pool-wrapper text-center text-white">
                                            <div id="lastdraw-lottery-main-3" class="text-center prize-wrapper">
                                                <div class="prize-block d-inline-block ball-9">
                                                    <div class="prize-digit"> <span id="lastdraw-lottery-main-3-1"
                                                            data-parent="lastdraw-lottery-main-3"><script>document.write(ConsoWinStr[0]);</script></span> </div>
                                                </div>
                                                <div class="prize-block d-inline-block ball-5">
                                                    <div class="prize-digit"> <span id="lastdraw-lottery-main-3-2"
                                                            data-parent="lastdraw-lottery-main-3"><script>document.write(ConsoWinStr[1]);</script></span> </div>
                                                </div>
                                                <div class="prize-block d-inline-block ball-8">
                                                    <div class="prize-digit"> <span id="lastdraw-lottery-main-3-3"
                                                            data-parent="lastdraw-lottery-main-3"><script>document.write(ConsoWinStr[2]);</script></span> </div>
                                                </div>
                                                <div class="prize-block d-inline-block ball-4">
                                                    <div class="prize-digit"> <span id="lastdraw-lottery-main-3-4"
                                                            data-parent="lastdraw-lottery-main-3"><script>document.write(ConsoWinStr[3]);</script></span> </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-7">
                        <div class="widget-box bg-color-3 px-3 py-5">
                            <!-- TradingView Widget BEGIN -->
                            <div class="tradingview-widget-container">
                                <div class="tradingview-widget-container__widget"></div>
                                <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-timeline.js" async>
                                        {
                                            "feedMode": "all_symbols",
                                                "colorTheme": "dark",
                                                    "isTransparent": true,
                                                        "displayMode": "regular",
                                                            "width": "100%",
                                                                "height": "350",
                                                                    "locale": "en"
                                        }
                                    </script>
                            </div>
                            <!-- TradingView Widget END -->
                        </div>
                    </div>
                </div>
            </div>
    </section>


    <!-- component footer below -->
    <footer>
        <div class="container px-3 py-0">
            <div class="footer-wrapper px-3 py-4">
                <div class="row no-gutters">
                    <div class="col-12">
                        <div class="logo-wrapper mb-3">
                            <a href="https://lotteriamexico.com"><img class="web-logo"
                                    src="https://i.ibb.co/jwwgsXM/MEXICO.png"></a>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="header-welcome">
                            <p class="text-black text-center mb-0">
                                <small><b>Mexico Prize</b></small><small> is a legal lottery information site that
                                    provides lottery results and similar games. And thank you for giving us the
                                    opportunity to introduce you to one of the most popular sites today. We are not
                                    affiliated with or connected with any official or unofficial lottery or gaming
                                    company whose logo appears or does not appear on this site.</small>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="copyright-wrapper bg-color-3 px-3 py-3">
                <div class="row no-gutters justify-content-between align-items-center">
                    <div class="col-12 col-lg-auto">
                        <p class="text-white text-center mb-0">
                            <small>Copyright &copy; 2023 <b>Mexico Prize</b>, All rights reserved.</small>
                        </p>
                    </div>
                    <div class="col-12 col-lg-auto">
                        <nav class="navbar navbar-main navbar-dark navbar-expand px-0 py-0">
                            <div class="navbar-collapse text-center my-0">
                                <ul class="navbar-nav ml-auto mr-auto">
                                    <li id="menu-item-154"
                                        class="menu-item menu-item-type-custom menu-item-object-custom menu-item-154 nav-item">
                                        <a title="Policy" href="#" class="nav-link">Policy</a></li>
                                    <li id="menu-item-155"
                                        class="menu-item menu-item-type-custom menu-item-object-custom menu-item-155 nav-item">
                                        <a title="Terms" href="#" class="nav-link">Terms</a></li>
                                    <li id="menu-item-156"
                                        class="menu-item menu-item-type-custom menu-item-object-custom menu-item-156 nav-item">
                                        <a title="License" href="#" class="nav-link">License</a></li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>

</html>